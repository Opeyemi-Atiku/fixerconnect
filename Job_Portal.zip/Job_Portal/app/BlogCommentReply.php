<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlogCommentReply extends Model
{
    //
}
