<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubscribePlan extends Model
{
    //
}
