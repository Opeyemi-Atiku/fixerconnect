$(function(){
  $('#mobile_profile').click(function(){
    location.href = '/profile/technician';
  });
  $('#desktop_profile').click(function(){
    location.href = '/profile/technician';
  });
});
