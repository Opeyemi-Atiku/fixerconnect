<?php $__env->startSection('title', 'Commercial Request Service'); ?>
<?php $__env->startSection('content'); ?>
<section>
  <div class="block no-padding  gray">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner2">
            <div class="inner-title2">
              <h3>Register</h3>
            </div>
            <div class="page-breacrumbs">
              <ul class="breadcrumbs">
                <li><a href="#" title="">Home</a></li>
                <li><a href="#" title="">Register</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="wow bounceInDown" id="signup_how_it_work">
  <div class="block remove-bottom">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="account-popup-area signup-popup-box static">
            <div class="account-popup">
              <h3>Commercial Service Request</h3>

              <div class="select-user" style="width: 440px !important;">
                

                <?php if(session('status')): ?>
                  <span style="">
                    <?php echo e(session('status')); ?>

                  </span>
                <?php endif; ?>
              </div>
              <form role="form" method="post" action="<?php echo e(url('/commercial/request')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <!--Residential input-->
                <div class="residential">
                  <!--residential name-->
                  <?php if($errors->has('name')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('name')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="" name="name" type="text" value="<?php echo e(old('name')); ?>" placeholder="Name"  required/>
                    <i class="la la-user"></i>
                  </div>

                  <!--residential email-->
                  <?php if($errors->has('email')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('email')); ?>

                    </span>
                  <?php endif; ?>
                  <?php if(session('error_email')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e(session('error_email')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="" name="email" type="email" value="<?php echo e(old('email')); ?>" placeholder="Email"  required/>
                    <i class="la la-envelope-o"></i>
                  </div>

                  <!--residential phone-->
                  <?php if($errors->has('phone')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('phone')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="" name="phone"  value="<?php echo e(old('phone')); ?>" type="text" placeholder="Phone Number" required/>
                    <i class="la la-phone"></i>
                  </div>

                </div>
                <!--Residential Input-->
                <button type="submit">Submit</button>
              </form>
            </div>
          </div><!-- SIGNUP POPUP -->
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>