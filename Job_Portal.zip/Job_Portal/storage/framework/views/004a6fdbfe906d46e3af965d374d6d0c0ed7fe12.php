<link rel="stylesheet" href="css/apps/email.css">
  <div id="invoice-POS">
    <center id="top" >
      <div class="logo"></div>
      <img src="<?php echo e(asset('images/storage/logo.png')); ?>" height="150px" style="z-index: 9999999; background-color: grey; background-size: 100px;">
      <div class="info">
      </div><!--End Info-->
    </center><!--End InvoiceTop-->

    <div id="bot">

					<div id="legalcopy">
						<p class="legal">Hello, <strong><?php echo e(Auth::user()->name); ?></strong><br/> thank you for signing up</p>
            <p class="legal"><a href="www.job.net/verificat_token_/<?php echo e(Auth::user()->remember_token); ?>"><button>Verify</button></a></p>
					</div>

				</div><!--End InvoiceBot-->
  </div><!--End Invoice-->
