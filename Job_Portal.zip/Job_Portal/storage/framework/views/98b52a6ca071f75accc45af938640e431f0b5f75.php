<?php $__env->startSection('content'); ?>

<!--Title-->
<?php echo $__env->make('source_file.Dashboard.Employer.inc.title_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Title-->

<section>
  <div class="block no-padding">
    <div class="container">
       <div class="row no-gape">
         <!--Menu-->
        <?php echo $__env->make('source_file.Dashboard.Employer.inc.menu_tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Menu-->

        <!--App-->
        <div class="col-lg-9 column">
          <div class="padding-left">
            <div class="manage-jobs-sec">
              <h3>Set Account</h3>
              <div class="change-password">
                <form class="needs-validation" method="Post" action="<?php echo e(url('/set_account_type')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="row">
                    <div class="col-lg-6">
                      <span class="pf-title">Choose Account</span>
                      <?php if(session('error')): ?>
                        <span style="color: #B22222; float: right">
                          <?php echo e(session('error')); ?>

                        </span>
                      <?php endif; ?>
                      <div class="pf-field">
                        <select data-placeholder="Please Select Specialism" class="chosen" name="account">
													<option value="2">Residential</option>
													<option value="3">Commercial</option>
												</select>
                      </div>
                      <button type="submit">Update</button>
                    </div>
                    <div class="col-lg-6">
                      <i class="la la-user big-icon"></i>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!--App-->

       </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>