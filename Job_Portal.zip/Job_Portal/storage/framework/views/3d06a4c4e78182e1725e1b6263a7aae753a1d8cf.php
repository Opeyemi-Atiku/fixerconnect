<!--profile image-->
<style type="text/css">
label::before, label::after{
  width:0px !important;
  height:0px !important;
  border: 0px !important;
}
label{
  padding: 0 !important;
  height: 0px;
}
</style>
<!--profile image-->
<?php $__env->startSection('title', 'Edit Profile'); ?>
<?php $__env->startSection('content'); ?>

<!--Title-->
<?php echo $__env->make('source_file.Dashboard.Employee.inc.title_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Title-->

<section>
  <div class="block no-padding">
    <div class="container">
       <div class="row no-gape">
         <!--Menu-->
        <?php echo $__env->make('source_file.Dashboard.Employee.inc.menu_tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Menu-->

        <!--App-->
        <div class="col-lg-9 column">
          <div class="padding-left">
            <div class="profile-title">
              <h3>My Profile</h3>
              <div class="upload-img-bar">
                <?php
                if($auth_user->profile_image == null){
                  $profile_image_source = "/storage/storage/profile_image.png";
                }else{
                  $profile_image_source = "/storage/storage/$auth_user->profile_image";
                }
                $loading = "/images/loaders.gif";
                ?>
                <span class="round"><img src='<?php echo e(URL::asset("$profile_image_source")); ?>' style="width: 100%; height: 160px;" id="set_profile_image" /></span>
                <div class="upload-info">
                  <a><label for="profile_image">Browse</label></a>
                  <input type="file" name="profile_image" id="profile_image" style="display: none;"/>
                </div>
              </div>
            </div>

            <div class="profile-form-edit">
              <div class="row">
                <!--name-->
                <div class="col-lg-6">
                  <span class="pf-title" id="fullname_">Full Name</span>
                  <div class="pf-field">
                    <input type="text" id="fullname" placeholder="Enter your fullname" value="<?php echo e($auth_user->name); ?>"/>
                  </div>
                </div>
                <!--trade type-->
                <div class="col-lg-6">
                  <span class="pf-title">Trade Type</span>
                  <div class="dropdown-field">
            				<select id="trade_type" data-placeholder="Please Select Trade Type" class="chosen">
                      <option disabled>Trade</option>
                      <?php $__currentLoopData = $tradeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <?php $act = ""; if($trade->id == $auth_user->trade_id){$act = "selected";}?>
            					<option <?php echo e($act); ?> value=<?php echo e($trade->id); ?>><?php echo e($trade->trade_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            				</select>
            			</div>
                </div>
                <!--experience-->
                <div class="col-lg-12">
                  <span class="pf-title" id="experience_">Description</span>
                  <div class="pf-field">
                    <textarea id="experience"><?php echo e($auth_user->experience); ?></textarea>
                  </div>
                </div>
                <!--submit-->
                <div class="col-lg-12">
                  <button id="update" type="submit">Update</button>
                </div>
              </div>
            </div>
            <div class="contact-edit">
              <h3>Contact</h3>
              <form>
                <div class="row">
                  <!--location-->
                  <div class="col-lg-6">
                    <span class="pf-title">Address</span>
                    <div class="pf-field">
                      <input id="address" type="text" value="<?php echo e($auth_user->location); ?>" />
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <span class="pf-title">Street Number</span>
                    <div class="pf-field">
                      <input id="streetNumber" type="text" placeholder="Enter street number" value="" />
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <a id="search" id="search" class="srch-lctn">Search Location</a>
                  </div>
                  <div class="col-lg-12">
                    <span class="pf-title">Maps</span>
                    <div class="pf-map" id="map">
                      <div id="googleMap" style="width: 100%; height: 250px;"></div>
                    </div>
                    <div class="container" id="loading">
                      <div class="row" id="loadings1">
                        <div class="col-md-2"></div>
                        <div class="col-md-6">
                          <img src="<?php echo e(URL::asset('images/loaders.gif')); ?>" alt="" />
                        </div>
                        <div class="col-md-4"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!--App-->
       </div>
    </div>
  </div>
</section>


<script>
var latitude, longitude;
var showMap = 1;
var loading = "<?php echo $loading;?>";

$(function(){
  /*
  * if location is set
  */
  var user_location_check = <?php if(isset($user_location_view)){echo 1;}else{echo 2;}?>;
  if(user_location_check == 1){
    latitude = <?php if(isset($user_location_view)){echo $user_location_view->latitude;}else{echo 1;}?>;
    longitude = <?php  if(isset($user_location_view)){echo $user_location_view->longitude;}else{echo 1;}?>;
    showMap = 2;
  }
  /*
  * if location is set set latitude and longitude
  */
});
</script>
<script src="<?php echo e(URL::asset('js/apps/edit_profile_employee.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('js/apps/map.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>