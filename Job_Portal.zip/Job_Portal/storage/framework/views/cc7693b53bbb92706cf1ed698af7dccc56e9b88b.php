<?php $__env->startSection('content'); ?>

<!--Title-->
<?php echo $__env->make('source_file.Dashboard.Employer.inc.title_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Title-->

<section>
  <div class="block no-padding">
    <div class="container">
       <div class="row no-gape">
         <!--Menu-->
        <?php echo $__env->make('source_file.Dashboard.Employer.inc.menu_tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Menu-->

        <!--App-->
        
        <!--App-->

       </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>