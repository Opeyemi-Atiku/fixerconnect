<?php $__env->startSection('title', 'Technician List'); ?>
<?php $__env->startSection('content'); ?>

<!--Title-->
<?php echo $__env->make('source_file.Dashboard.Employer.inc.title_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Title-->

<section>
  <div class="block no-padding">
    <div class="container">
       <div class="row no-gape">
         <!--Menu-->
        <?php echo $__env->make('source_file.Dashboard.Employer.inc.menu_tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Menu-->

        <!--App-->
        <div class="col-lg-9 column">
          <div class="padding-left">
                <div class="emply-list-sec">
                        <?php $__currentLoopData = $technician; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technician_): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php
                        $profile_image_source = "/storage/storage/$technician_->profile_image";
                        //$link = "/job/technician/$job->id";
                        ?>
            
                        <div class="emply-resume-list round justify-content-center">
                          <div class="emply-resume-thumb">
                            <img src="<?php echo e($profile_image_source); ?>" alt="" />
                          </div>
                          <div class="emply-resume-info">
                            <h3><a href="#" title=""><?php echo e($technician_->name); ?></a></h3>
                            <span><?php echo e($technician_->trade_type); ?></span>
                            <p><i class="la la-map-marker"></i><?php echo e($technician_->location); ?></p>
                          </div>
                          <div class="shortlists">
                            <a href="/view_technician/<?php echo e($technician_->id); ?>" title="">Hire <i class="la la-plus"></i></a>
                          </div>
                        </div><!-- Emply List -->                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <div class="pagination">
                            <ul>
                                    <?php if($technician->currentPage() > 1): ?>
                                    <li class="prev"><a href="<?php echo e($technician->previousPageUrl()); ?>"><i class="la la-long-arrow-left"></i> Prev</a></li>
                                    <?php endif; ?>
                                    <?php if($technician->currentPage() != $technician->lastPage() && $technician->lastPage() != 0): ?>
                                    <li class="next"><a href="<?php echo e($technician->nextPageUrl()); ?>">Next <i class="la la-long-arrow-right"></i></a></li>
                                    <?php endif; ?>
                            </ul>
                        </div><!-- Pagination -->
          
          
                 </div>
            </div>
          </div>
        <!--App-->

       </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>