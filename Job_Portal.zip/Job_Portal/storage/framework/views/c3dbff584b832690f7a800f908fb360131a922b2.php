<?php $__env->startSection('content'); ?>

<!--Title-->
<?php echo $__env->make('source_file.Dashboard.Employer.inc.title_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Title-->

<section>
  <div class="block no-padding">
    <div class="container">
       <div class="row no-gape">
         <!--Menu-->
        <?php echo $__env->make('source_file.Dashboard.Employer.inc.menu_tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Menu-->

        <!--App-->
        <div class="col-lg-9 column">
          <div class="padding-left">
            <div class="manage-jobs-sec">
              <h3>Transactions</h3>
              <table>
                <thead>
                  <tr>
                    <td>lorem Ipsum</td>
                    <td>Lorem Ipsum</td>
                    <td>Lorem Ipsum</td>
                    <td>Lorem Ipsum</td>
                    <td>Lorem Ipsum</td>
                    <td>Lorem Ipsum</td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <span>221319456</span>
                    </td>
                    <td>
                      <div class="table-list-title">
                        <h3><a href="#" title="">Advertise job - Supper Jobs</a></h3>
                      </div>
                    </td>
                    <td>
                      <span>April 04, 2017</span>
                    </td>
                    <td>
                      <span>Pre Bank Transfer</span>
                    </td>
                    <td>
                      <span class="status active">$99</span>
                    </td>
                    <td>
                      <span>Pending</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!--App-->

       </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>