<?php
if(Auth::guard()->check() == true){
  $link = '/redirect_dashboard';
}else{
  $link = '/user/register';
}
?>
<div class="responsive-header">
  <div class="responsive-menubar">
    <div class="res-logo"><a href="/" title=""><img class="logo" src="<?php echo e(URL::asset('images/resource/logo.png')); ?>" alt="" /></a></div>
    <div class="menu-resaction">
      <div class="res-openmenu">
        <img src="<?php echo e(URL::asset('images/icon.png')); ?>" alt="" /> Menu
      </div>
      <div class="res-closemenu">
        <img src="<?php echo e(URL::asset('images/icon2.png')); ?>" alt="" /> Close
      </div>
    </div>
  </div>
  <div class="responsive-opensec">
    <div class="btn-extars">
      <?php if(Auth::guard()->check() == true): ?>
      <?php if(Auth::user()->account_type == 1): ?>
      <!--<div class="my-profiles-sec" style="float:left;">
					<span id="mobile_profile"><img src="<?php echo e(URL::asset('images/resource/mp1.jpg')); ?>" style="" alt="" /></span>
			</div>-->
      <?php endif; ?>
      <?php endif; ?>
      <ul class="account-btns">
        <?php if(Auth::guard()->check() == false): ?>
        <li><a href="/user/register" title="" class="post-job-btn">Sign Up</a></li>
        <li><a href="/user/login" title="" class="post-job-btn">Login</a></li>
        <?php else: ?>
        <li><a href="/logout" class="post-job-btn">Logout</a></li>
        <?php endif; ?>
      </ul>
    </div><!-- Btn Extras -->
    <div class="responsivemenu">
      <ul>
          <li class="menu-item">
            <a href="/register/residential" title="">Residential</a>
          </li>
          <li class="menu-item">
            <a href="/register/commercial" title="">Commercial</a>
          </li>
          <li class="menu-item">
            <a href="/register/technician" title="">Technician</a>
          </li>
          <li class="menu-item">
            <a href="/contact" title="">Apprenticeship Program</a>
          </li>
          <li class="menu-item">
            <a href="/about" title="">Download APP</a>
          </li>
          <li class="menu-item">
            <a href="/blog" title="">Blog</a>
          </li>
        </ul>
    </div>
  </div>
</div>
<header class="white">
  <div class="menu-sec">
    <div class="container">
      <div class="logo">
        <a href="/" title=""><img class="hidesticky" src="" alt="" /><img class="logo" src="<?php echo e(URL::asset('images/resource/logo.png')); ?>" alt="" /></a>
      </div><!-- Logo -->
      <div class="btn-extars">
        <?php if(Auth::guard()->check() == true): ?>
        <?php if(Auth::user()->account_type == 1): ?>
        <!-- <div class="my-profiles-sec" style="float:left;">
  					<span id="desktop_profile"><img style="margin-right: 10px;" src="<?php echo e(URL::asset('images/resource/mp1.jpg')); ?>" alt="" /></span>
  			</div> -->
        <?php endif; ?>
        <?php endif; ?>
        <ul class="account-btns">
          <?php if(Auth::guard()->check() == false): ?>
          <li><a href="/user/login" class="post-job-btn">Login</a></li>
          <li><a href="/user/register" class="post-job-btn" title="">Sign Up</a></li>
          <?php else: ?>
          <li><a href="/logout" class="post-job-btn">Logout</a></li>
          <?php endif; ?>
        </ul>
      </div><!-- Btn Extras -->
      <nav>
        <ul>
          <li class="menu-item">
            <a href="/register/residential" title="">Residential</a>
          </li>
          <li class="menu-item">
            <a href="/register/commercial" title="">Commercial</a>
          </li>
          <li class="menu-item">
            <a href="/register/technician" title="">Technician</a>
          </li>
          <li class="menu-item">
            <a href="/contact" title="">Apprenticeship Program</a>
          </li>
          <li class="menu-item">
            <a href="/about" title="">Download APP</a>
          </li>
          <li class="menu-item">
            <a href="/blog" title="">Blog</a>
          </li>
        </ul>
      </nav><!-- Menus -->
    </div>
  </div>
</header>
<script src="<?php echo e(URL::asset('js/apps/header.js')); ?>" type="text/javascript"></script>
