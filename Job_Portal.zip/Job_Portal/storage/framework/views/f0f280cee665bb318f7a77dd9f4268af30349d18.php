<?php $__env->startSection('title', 'Jobs'); ?>
<?php $__env->startSection('content'); ?>

<!--Title-->
<?php echo $__env->make('source_file.Dashboard.Employer.inc.title_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Title-->
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/apps/chat_and_job_navigation.css')); ?>" />


<!--App-->
<section id="app">
  <div class="block">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 column">
          <div class="job-single-sec style3">
            <div class="job-head-wide">
              <div class="row">
                <div class="col-lg-8">
                  <div class="job-single-head3">
                    <!--<div class="job-thumb"> <img src="images/resource/sdf.png" alt="" /><span>12 Open Position</span> </div>-->
                    <div class="job-single-info3">
                      <h3><?php echo e($job->title); ?></h3>
                      <span><i class="la la-map-marker"></i><?php echo e($job->address); ?></span><span class="job-is ft"><?php echo e($job->trade_name); ?></span>
                      <ul class="tags-jobs">
                        <!--<li><i class="la la-file-text"></i> Applications 1</li>-->
                        <li><i class="la la-calendar-o"></i> <?php echo e($job->created_at->diffForHumans()); ?> </li>
                        <li><i class="la la-money"></i> $<?php echo e($job->budget_from); ?> - $<?php echo e($job->budget_to); ?></li>
                        <li><a href="/view_profile/<?php echo e($job->user_id); ?>"><i class="la la-user"></i><?php echo e($job->company_name); ?></a></li>
                      </ul>
                    </div>
                  </div><!-- Job Head -->
                </div>
                <div class="col-lg-4">
                  <?php if($account == 'Technician'): ?>
                  <?php if($applied == 2): ?>
                  <a class="apply-thisjob" title="" id="apply"><i class="la la-paper-plane"></i>Apply for job</a>
                  <?php elseif($applied == 1): ?>
                  <a class="apply-thisjob" title="" id="applied"><i class="la la-paper-plane"></i>Applied</a>
                  <?php endif; ?>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <div class="job-wide-devider">
              <div class="row">
                <div class="col-lg-8 column">
                  <div class="job-details">
                    <h3>Job Description</h3>
                    <p><?php echo e($job->description); ?></p>
                  </div>
                  <h4>Location</h4>
                  <div class="pf-map" id="map">
                    <div id="googleMap" style="width: 100%; height: 250px;"></div>
                  </div>
                  <div class="recent-jobs">
                    <h3>Technician</h3>
                    <div class="job-list-modern">
                      <div class="job-listings-sec no-border">
                        <?php if(count($accept_applicant) > 0): ?>
                        <?php $__currentLoopData = $accept_applicant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant__): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php
                        $profile_image_source = "/storage/storage/$applicant__->profile_image";
                        ?>
                        <div class="job-listing wtabs">
                          <div class="job-title-sec">
                            <div class="c-logo"> <img src='<?php echo e(URL::asset("$profile_image_source")); ?>'  style="width: 90px; height: 90px;" class="img-thumbnail rounded-circle" /> </div>
                            <h3><a title=""><?php echo e($applicant__->name); ?></a></h3>
                            <span><i class="la la-comment"></i><?php echo e(substr($applicant__->review, 0, 12)); ?></span>
                            <div class="job-lctn"><i class="la la-map-marker"></i><?php echo e($applicant__->address); ?></div>
                          </div>
                          <div class="job-style-bx">
                            <?php if($job->user_id == Auth::id()): ?>
                            <?php if($applicant__->review_status == 2): ?>
                            <span class="job-is ft signin-popup" user_id="<?php echo e($applicant__->user_id); ?>" name="<?php echo e($applicant__->name); ?>" id="popup__">Add Review</span>
                            <?php elseif($applicant__->review_status == 1): ?>
                            <span class="job-is ft signin-popup" user_id="<?php echo e($applicant__->user_id); ?>" name="<?php echo e($applicant__->name); ?>" id="popup__">Update Review</span>
                            <?php endif; ?>
                            <?php endif; ?>
                          </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <!--review-->
                        <div class="account-popup-area signin-popup-box">
                        	<div class="account-popup">
                            <h3 id="name_review"></h3>
                            <span id="review_validation"></span>
                        		<span class="close-popup"><i class="la la-close"></i></span>
                        		<form>
                        			<div class="cfield">
                        				<input type="text" name="review" id="review" placeholder="Enter Review" />

                        			</div>
                        			<a class="post-job-btn" id="review__"><i class="la la-comment"></i>Submit Review</a>
                        		</form>
                        	</div>
                        </div>
                        <!--Review-->
                        .
                        <div class="row" id="project_navigation">
                          <div class="col-lg-6 col-sm-6 col-md-6">
                            <?php if($accept_applicant->currentPage() > 1): ?>
                            <a href="<?php echo e($accept_applicant->previousPageUrl()); ?>">
                              <span class="job-is ft">previous</span>
                              </button>
                            </a>
                            <?php endif; ?>
                          </div>
                          <div class="col-lg64 col-sm-6 col-md-6">
                            <?php if($accept_applicant->currentPage() != $accept_applicant->lastPage() && $accept_applicant->lastPage() != 0): ?>
                            <a href="<?php echo e($accept_applicant->nextPageUrl()); ?>">
                              <span class="job-is ft">next</span>
                              </button>
                            </a>
                            <?php endif; ?>
                          </div>
                        </div>

                        <?php else: ?>
                        No Worker
                        <?php endif; ?>
                      </div>
                     </div>
                  </div>
                </div>


                <div class="col-lg-4 column">
                  <?php if($account == 'Technician'): ?>
                  <div class="quick-form-job" id="applyForm">
                      <input type="text" name="bid" id="bid" placeholder="Enter your bid price" />
                      <span id="validation"></span>
                      <button id="bidSubmit" class="submit">Bid</button>
                  </div>
                  <div class="row" id="loading">
                    <div class="col-md-2"></div>
                    <div class="col-md-6">
                      <img src="<?php echo e(URL::asset('images/loaders.gif')); ?>" alt="" style="width: 100%; height: 100%;" />
                    </div>
                    <div class="col-md-4"></div>
                  </div>
                  <?php endif; ?>
                  <div class="job-overview">
                    <?php if($account == 'Technician'): ?>
                    <?php if($applied == 1): ?>
                    <div id="message" user_id="<?php echo e($job->user_id); ?>" price="<?php echo e($price); ?>"><ul><a class="apply-thisjob"><i class="la la-comments"></i>Open Chat</a></ul></div>
                    <?php endif; ?>
                    <?php endif; ?>
                    <h3>Bid And Invitation</h3>
                    <ul>
                      <?php if(count($applicant) > 0): ?>
                      <?php $__currentLoopData = $applicant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <?php
                      $profile_image_source = "/storage/storage/$app->profile_image";
                      ?>
                      <?php if($job->user_id == Auth::id()): ?>
                      <div class="item d-flex align-items-center" id="message" user_id="<?php echo e($app->user_id); ?>" price="<?php echo e($app->bid_price); ?>">
                        <?php else: ?>
                          <div class="item d-flex align-items-center" user_id="<?php echo e($app->user_id); ?>">
                        <?php endif; ?>
                        <div class="image"><img src='<?php echo e(URL::asset("$profile_image_source")); ?>' style="width: 70px; height: 70px;" class="img-thumbnail rounded-circle"></div>

                        <div class="text" style="margin-left: 10px;">
                          <a>
                             <?php echo e($app->name); ?><br/>
                          </a>
                          <?php if($job->user_id == Auth::id()): ?>
                          <a>
                            <?php if($app->status != 6): ?>
                            <small style="font-size: 15px;"> $<?php echo e($app->bid_price); ?></small>
                            <?php endif; ?>
                          </a>
                          <?php endif; ?>
                        </div>

                        <?php if($job->user_id == Auth::id()): ?>
                        <div id="applicant">
                          <?php if($app->status == 1): ?>
                          <button class="post-job-btn" style="font-size: 10px; padding: 10px 5px !important"><span>pending</span></button>
                          <?php elseif($app->status == 2): ?>
                          <button class="post-job-btn" style="font-size: 10px; padding: 10px 5px !important"><span>hired</span></button>
                          <?php elseif($app->status == 3): ?>
                          <button class="post-job-btn" style="font-size: 10px; padding: 10px 5px !important"><span>waiting</span></button>
                          <?php elseif($app->status == 4): ?>
                          <button class="post-job-btn" style="font-size: 10px; padding: 10px 5px !important"><span>paid</span></button>
                          <?php elseif($app->status == 5): ?>
                          <button class="post-job-btn" style="font-size: 10px; padding: 10px 5px !important"><span>Decline</span></button>
                          <?php elseif($app->status == 6): ?>
                          <button class="post-job-btn" style="font-size: 10px; padding: 10px 5px !important"><span>Invite</span></button>
                          <?php endif; ?>
                          <a><i class="la la-comments"></i></a>
                        </div>
                        <?php else: ?>
                        <?php if($account == 'Technician'): ?>
                        <!--<div id="applicant">
                          <?php if($app->status == 1): ?>
                          <button class="post-job-btn" style="font-size: 13px; padding: 10px 5px !important"><span>pending</span></button>
                          <?php elseif($app->status == 2): ?>
                          <button class="post-job-btn" style="font-size: 13px; padding: 10px 5px !important"><span>hired</span></button>
                          <?php elseif($app->status == 3): ?>
                          <button class="post-job-btn" style="font-size: 13px; padding: 10px 5px !important"><span>waiting</span></button>
                          <?php elseif($app->status == 4): ?>
                          <button class="post-job-btn" style="font-size: 10px; padding: 10px 5px !important"><span>paid</span></button>
                          <?php endif; ?>
                        </div>-->
                        <?php endif; ?>
                        <?php endif; ?>
                      </div>


                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      <div class="row" id="project_navigation">
                        <div class="col-lg-6 col-sm-6 col-md-6">
                          <?php if($applicant->currentPage() > 1): ?>
                          <a href="<?php echo e($applicant->previousPageUrl()); ?>">
                            <span class="job-is ft">previous</span>
                            </button>
                          </a>
                          <?php endif; ?>
                        </div>
                        <div class="col-lg64 col-sm-6 col-md-6">
                          <?php if($applicant->currentPage() != $applicant->lastPage() && $applicant->lastPage() != 0): ?>
                          <a href="<?php echo e($applicant->nextPageUrl()); ?>">
                            <span class="job-is ft">next</span>
                            </button>
                          </a>
                          <?php endif; ?>
                        </div>
                      </div>
                      <?php else: ?>
                      No bid
                      <?php endif; ?>
                    </ul>


                  </div><!-- Job Overview -->
                </div>
              </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--App-->

<!--loading-->
<section id="loading">
  <div class="row" id="loading">
    <div class="col-md-2"></div>
    <div class="col-md-6">
      <img src="<?php echo e(URL::asset('images/loaders.gif')); ?>" alt="" style="width: 100%; height: 100%;" />
    </div>
    <div class="col-md-4"></div>
  </div>
</section>
<!--loading-->

<!--ChatApp-->
<section id="chat">
  <div class="container">
    <div class="messaging">
      <div class="inbox_msg">
        <div class="inbox_people">
          <div class="headind_srch">
            <div class="recent_heading">
              <h4>Recent</h4>
            </div>
          </div>
          <div class="inbox_chat" id="contactList">

          </div>
        </div>
        <div class="mesgs">
          <!--<div class="t-center" id="newMessageChat"><button class="button button--small button--primary"><span style="color:white;">view new message</span></button></div>-->
          <div class="t-center" id="job_status_viewer">
            <button class="post-job-btn" id="hired_status" style="float: right !important; font-size: 10px; padding: 2px 15px !important;"><span id="job_status"></span></button>
            <button class="post-job-btn" id="choose_yes" style="float: right !important; font-size: 8px; padding: 2px 15px !important;"><span id="yes"></span>Yes</button>
            <button class="post-job-btn" id="choose_no" style="float: right !important; font-size: 8px; padding: 2px 15px !important;"><span id="no"></span>No</button>
          </div>

          <div id="current"><a id="currentUserLink"><img class="img-thumbnail rounded-circle" src="/storage/storage/profile_image.png" id="currentImage" height="50px" width="50px"><h5 id="currentName"></h5></a></div>


          <div class="msg_history">
            <div id="front" class="frontMessageView">

            </div>
            <div class="type_msg">
              <div class="input_msg_write">
                <input type="text" class="write_msg" placeholder="Type a message" id="message" />
                <button  id="sendMessage" msg="message" class="msg_send_btn" type="button"><i class="fa fa-paper-plane-o" style="margin-left: -10px" aria-hidden="true"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--ChatApp-->


<script>
var latitude = "<?php echo $job->latitude; ?>";
var longitude = "<?php echo $job->longitude; ?>";
var transact_account_ = "<?php echo lcfirst($account);?>";
var showMap = 2;
var job_id = <?php echo $job->id; ?>;
var total_message_fetch;
var auth_user = <?php echo Auth::id();?>;
var inbox_message_count_;
var user_fetch;
var user_id;
var total_contact = 0;
var previous_id;
var popUpNew = 2;
var new_message_sent = 1;
$(function(){
    if(transact_account_ === 'technician'){
        $('#job_status_viewer').hide();
    }
});

var user_id_review;
var name_review;
var message_review;
</script>


<script src="<?php echo e(URL::asset('js/apps/job_view_navigation_.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('js/apps/review.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('js/apps/employer_message6.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('js/apps/map.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>