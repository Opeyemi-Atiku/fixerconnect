<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('content'); ?>
<section>
  <div class="block no-padding  gray">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner2">
            <div class="inner-title2">
              <h3>Register</h3>
            </div>
            <div class="page-breacrumbs">
              <ul class="breadcrumbs">
                <li><a href="#" title="">Home</a></li>
                <li><a href="#" title="">Register</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="wow bounceInDown" id="signup_how_it_work">
  <div class="block remove-bottom">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="account-popup-area signup-popup-box static">
            <div class="account-popup">
              <h3>Sign Up</h3>

              <div class="select-user">
                <span id="residential-option">Residential</span>
                

                <?php if(session('store_error')): ?>
                  <span style="color: #B22222;">
                    <?php echo e(session('store_error')); ?>

                  </span>
                <?php endif; ?>
              </div>
              <form role="form" method="post" action="<?php echo e(url('/user/register')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <!--Residential input-->
                <div class="residential">
                  <!--residential name-->
                  <?php if($errors->has('name_residential')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('name_residential')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="residential-input1" name="name_residential" type="text" value="<?php echo e(old('name_residential')); ?>" placeholder="Name"  required/>
                    <i class="la la-user"></i>
                  </div>

                  <!--residential email-->
                  <?php if($errors->has('email_residential')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('email_residential')); ?>

                    </span>
                  <?php endif; ?>
                  <?php if(session('error_email')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e(session('error_email')); ?>

                    </span>
                  <?php endif; ?>
                  <?php
                  /*
                  * if email has error
                  */
                  if($errors->has('email_residential')){
                    $error_validation_email_residential = old('email_residential');
                  }else{
                    $error_validation_email_residential = '';
                  }
                  ?>
                  <div class="cfield">
                    <input id="residential-input2" name="email_residential" type="email" value="<?php echo e($error_validation_email_residential); ?>" placeholder="Email"  required/>
                    <i class="la la-envelope-o"></i>
                  </div>

                  <!--residential password-->
                  <?php if($errors->has('password_residential')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('password_residential')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="residential-input3" name="password_residential" type="password" placeholder="Enter password"  required/>
                    <i class="la la-key"></i>
                  </div>
                  <?php if($errors->has('password_confirmation_residential')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('password_confirmation_residential')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="residential-input6" name="password_confirmation_residential" type="password" placeholder="Confirm password"  required/>
                    <i class="la la-key"></i>
                  </div>

                  <!--residential address-->
                  <?php if($errors->has('address_residential')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('address_residential')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="residential-input4" name="address_residential" value="<?php echo e(old('address_residential')); ?>" type="text" placeholder="Address"  required/>
                    <i class="la la-map-marker"></i>
                  </div>

                  <!--residential phone-->
                  <?php if($errors->has('phone_residential')): ?>
                    <span style="color: #B22222; float: right">
                      <?php echo e($errors->first('phone_residential')); ?>

                    </span>
                  <?php endif; ?>
                  <div class="cfield">
                    <input id="residential-input5" name="phone_residential"  value="<?php echo e(old('phone_residential')); ?>" type="text" placeholder="Phone Number" required/>
                    <i class="la la-phone"></i>
                  </div>

                </div>
                <!--Residential Input-->

                <?php
                /*
                * selected hidden user option
                */
                if(old('user_option_type')){
                  $user_type_selected = old('user_option_type');
                }else{
                  $user_type_selected = 'residential';
                }
                ?>
                <!--Technician Input-->
                <input type="hidden" id="user_option_type" name="user_option_type" value="<?php echo e($user_type_selected); ?>">
                <button type="submit">Signup</button>
              </form>
              <span>
                <a href="/user/login" title="">Already have an account? Sign in</a>
              </span>

              <div class="extra-login">
                <span>Or</span>
                <div class="login-social">
                  <a class="fb-login" href="<?php echo e(URL::asset('social/facebook')); ?>" title=""><i class="fa fa-facebook"></i></a>
                  <a class="gl-login" href="<?php echo e(URL::asset('social/google')); ?>" title=""><i class="fa fa-google-plus"></i></a>
                </div>
              </div>
            </div>
          </div><!-- SIGNUP POPUP -->
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>