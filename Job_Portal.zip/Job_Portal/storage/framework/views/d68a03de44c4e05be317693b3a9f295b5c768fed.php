<?php $__env->startSection('title', $blog->title); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/apps/blog.css')); ?>" />
<?php $__env->startSection('content'); ?>
<section>
  <div class="block">
    <div class="container">
      <div class="blog-single">
        <div class="bs-thumb"><img src="http://admin.job.net/storage/storage/<?php echo e($blog->image); ?>" width="100%" height="300px" alt="" /></div>



        <div class="col-lg-8 offset-2">
          <ul class="post-metas"><li><a href="#" title=""><i class="la la-user"></i><?php echo e($blog->author); ?></a></li><li><a href="#" title=""><i class="la la-calendar-o"></i><?php echo e($blog->created_at->diffForHumans()); ?></a></li><li><a class="metascomment" href="#" title="">
            <i class="la la-comments"></i><?php echo e(count($comment)); ?> comments</a></li><li><a href="#" title=""><i class="la la-file-text"></i><?php echo e($blog->tag); ?></a></li></ul>
          <h2><?php echo e($blog->title); ?></h2>
          <p><pre><?php echo html_entity_decode($blog->body);?></pre></p>


          <div class="comment-sec">
            <h3><?php echo e(count($comment)); ?> Comments</h3>
            <ul>
              <?php if(count($comment) > 0): ?>
              <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment_): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <li>
                <div class="comment">
                  <div class="comment-avatar"> <img style="width: 40px; height: 40px;" src="/storage/storage/<?php echo e($comment_->profile_image); ?>" alt="" /> </div>
                  <div class="comment-detail">
                    <h3><?php echo e($comment_->name); ?></h3>
                    <div class="date-comment"><i class="la la-calendar-o"></i><?php echo e($comment_->created_at->diffForHumans()); ?></div>
                    <p><?php echo e($comment_->comment); ?></p>

                    <?php if(Auth::check()): ?>
                    <a id="view_reply_" comment_id="<?php echo e($comment_->id); ?>"> <i class="la la-comment"></i>View Reply&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    <a id="comment_reply" comment_id="<?php echo e($comment_->id); ?>"><i class="la la-reply"></i>Reply</a>

                    <div id="comment_reply_input_<?php echo e($comment_->id); ?>"  class="cfield comment_reply_input">

                      <div class="col-lg-7 col-md-6 col-sm-6 offset-1">
                        <span id="comment_reply_error_<?php echo e($comment_->id); ?>">
                        <input id="reply_comment_<?php echo e($comment_->id); ?>" comment="<?php echo e($comment_->id); ?>" type="text" placeholder="Reply Comment" />
                        <button comment="<?php echo e($comment_->id); ?>" id="reply_comment">Reply</button>
                      </div>

                    </div>
                    <?php endif; ?>
                  </div>

                </div>
                <ul class="comment-child" id="comment-child_<?php echo e($comment_->id); ?>">
                </ul>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php else: ?>
              No comment
              <?php endif; ?>
            </ul>
          </div>

          <?php if(Auth::check()): ?>
          <div class="commentform-sec">
            <h3>Leave a Reply</h3>
            <form method="post" action="/blog/comment">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-lg-12">
                  <span class="pf-title">Description</span>
                  <div class="pf-field">
                    <input type="hidden" name="id" value="<?php echo e($blog->id); ?>" />

                    <?php if($errors->has('comment')): ?>
                        <span style="color: #B22222;">
                            <strong><?php echo e($errors->first('comment')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <textarea name="comment"></textarea>
                  </div>
                </div>
                <div class="col-lg-12">
                  <button type="submit">Post Comment</button>
                </div>
              </div>
            </form>
          </div>
          <?php endif; ?>


        </div>

      </div>
    </div>
  </div>
</section>



<script>
$(function(){

  /*
  * navigate
  */
  $('ul.comment-child').hide();
  $('div.comment_reply_input').hide();

  var show = 1;
  $('a#comment_reply').click(function(){

    var id = $(this).attr('comment_id');
    if(show == 1){
      $('div#comment_reply_input_'+id).show();
      $(this).html('<i class="la la-close"></i>CLose');
      show = 2;
    }else if(show == 2){
      $('div#comment_reply_input_'+id).hide();
      $(this).html('<i class="la la-reply"></i>Reply');
      show = 1;
    }
  });
  /*
  * navigate
  */

  /*
  * send reply to comment
  */
  $('button#reply_comment').click(function(){
    var id = $(this).attr('comment');
    var comment = $('input#reply_comment_'+id).val();
    $('input#reply_comment_'+id).val('');
    if(comment === ''){
      alert('reply field is required');
    }else{
      reply(id, comment)
    }
  });

  function reply(id, comment){
    $.ajax({
      type: 'post',
      url: '/comment_reply',
      credentials: 'same-origin',
      timeout: 100000,
      data : {
        id: id,
        comment: comment
      },
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      success: function(data){
        var vw = [];
        for(var dt = 0; dt < data.length; dt++){

          vw[dt] = '<li><div class="comment"><div class="comment-avatar"> <img style="width: 20px; height: 20px;" src="http://job.net/storage/storage/'+data[dt].profile_image+'" alt="" /> </div><div class="comment-detail"><h3>'+data[dt].name+'</h3><p>'+data[dt].comment+'</p></div></div></li>';

        }
        $('ul#comment-child_'+id).html(vw);
        $('ul#comment-child_'+id).show();
      },
      error: function(){
        alert('error occured');
      }
      });
  }
  /*
  * send reply to comment
  */


  /*
  * view reply to comment
  */
  var view_reply__ = 1;
  $('a#view_reply_').click(function(){
    var id = $(this).attr('comment_id');
    view_reply(id);
    if(view_reply__ == 1){
      $('ul#comment-child_'+id).show();
      view_reply__ = 2;
    }else{
      $('ul#comment-child_'+id).hide();
      view_reply__ = 1;
    }
  });

  function view_reply(id){
    $.ajax({
      type: 'post',
      url: '/view_reply',
      credentials: 'same-origin',
      timeout: 100000,
      data : {
        id: id,
      },
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      success: function(data){
        var vw = [];
        for(var dt = 0; dt < data.length; dt++){

          vw[dt] = '<li><div class="comment"><div class="comment-avatar"> <img style="width: 40px; height: 40px;" src="http://job.net/storage/storage/'+data[dt].profile_image+'" alt="" /> </div><div class="comment-detail"><h3>'+data[dt].name+'</h3><p>'+data[dt].comment+'</p></div></div></li>';

        }
        $('ul#comment-child_'+id).html(vw);
      },
      error: function(){
        alert('error occured');
      }
      });
  }
  /*
  * view reply to comment
  */


});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>