<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
<section>
  <div class="block">
    <div class="container">
       <div class="row">
        <div class="col-lg-12">


          <div class="blog-sec">
            <div class="row" id="masonry">
              <?php if(count($blog) > 0): ?>
              <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog_): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="my-blog">
                  <div class="blog-thumb">
                    <a href="/blog/<?php echo e($blog_->id); ?>" title=""><img src="http://admin.job.net/storage/storage/<?php echo e($blog_->image); ?>" width="200px" height=200px"" /></a>
                    <div class="blog-metas">
                      <a href="/blog/<?php echo e($blog_->id); ?>" title=""><?php echo e($blog_->created_at->diffForHumans()); ?></a>
                    </div>
                  </div>
                  <div class="blog-details">
                    <h3><a href="/blog/<?php echo e($blog_->id); ?>" title=""><?php echo e($blog_->title); ?></a></h3>
                    <p><?php echo e(substr($blog_->body, '0', '20')); ?></p>
                    <a href="/blog/<?php echo e($blog_->id); ?>" title="">Read More <i class="la la-long-arrow-right"></i></a>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php else: ?>
              <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="my-blog">
                  <div class="blog-thumb">
                    <div class="blog-metas">
                    </div>
                  </div>
                  <div class="blog-details">
                    <h3><a>No Blog Post</a></h3>
                  </div>
                </div>
              </div>
              <?php endif; ?>
            </div>
          </div>



          <div class="pagination">
            <ul>
              <?php if($blog->currentPage() > 1): ?>
                <li class="prev"><a href="<?php echo e($blog->previousPageUrl()); ?>"><i class="la la-long-arrow-left"></i> Prev</a></li>
              <?php endif; ?>
              <?php if($blog->currentPage() != $blog->lastPage() && $blog->lastPage() != 0): ?>
              <li class="next"><a href="<?php echo e($blog->nextPageUrl()); ?>">Next <i class="la la-long-arrow-right"></i></a></li>
              <?php endif; ?>

            </ul>
          </div><!-- Pagination -->


        </div>
       </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>