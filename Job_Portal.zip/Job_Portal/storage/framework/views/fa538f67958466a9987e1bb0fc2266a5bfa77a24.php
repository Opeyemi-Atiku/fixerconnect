<?php $__env->startSection('title', 'Reviews'); ?>
<?php $__env->startSection('content'); ?>

<!--Title-->
<?php echo $__env->make('source_file.Dashboard.Employee.inc.title_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Title-->

<section>
  <div class="block no-padding">
    <div class="container">
       <div class="row no-gape">
         <!--Menu-->
        <?php echo $__env->make('source_file.Dashboard.Employee.inc.menu_tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Menu-->

        <!--App-->
        <div class="col-lg-9 column">
          <div class="padding-left">
            <div class="emply-list-sec">
              <?php if(count($review) > 0): ?>
              <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <?php
              $profile_image_source = "/storage/storage/$view->profile_image";
              ?>

              <div class="job-listing wtabs">
                <div class="job-title-sec">
                  <div class="c-logo"><a href="/view_profile/<?php echo e($view->company_id); ?>"><img src='<?php echo e(URL::asset("$profile_image_source")); ?>'  style="width: 100px; height: 100px;" class="img-thumbnail rounded-circle" /></a></div>
                  <h3><a href="/view_profile/<?php echo e($view->company_id); ?>"><i class="la la-user"></i><?php echo e($view->name); ?></a></h3>
                  <h3><a><?php echo e($view->title); ?></a></h3>
                  <div class="job-lctn"><i class="la la-map-marker"></i><?php echo e($view->address); ?></div>
                  <span><i class="la la-comment"></i><?php echo e($view->review); ?></span>
                </div>
                <div>
                  <span class="job-is ft"><?php echo e($view->trade_name); ?></span>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php else: ?>
              No Review
              <?php endif; ?>
              .
              <div class="row" id="project_navigation">
                <div class="col-lg-6 col-sm-6 col-md-6">
                  <?php if($review->currentPage() > 1): ?>
                  <a href="<?php echo e($review->previousPageUrl()); ?>">
                    <span class="job-is ft">previous</span>
                    </button>
                  </a>
                  <?php endif; ?>
                </div>
                <div class="col-lg64 col-sm-6 col-md-6">
                  <?php if($review->currentPage() != $review->lastPage() && $review->lastPage() != 0): ?>
                  <a href="<?php echo e($review->nextPageUrl()); ?>">
                    <span class="job-is ft">next</span>
                    </button>
                  </a>
                  <?php endif; ?>
                </div>
              </div>


				 		</div>
          </div>
        </div>
        <!--App-->

       </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>