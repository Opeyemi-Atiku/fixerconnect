<?php
$user = Auth::user()->account_type;
switch ($user) {
  case 2:
    $account = 'Resedential';
    break;
  case 3:
    $account = 'commercial';
    break;
}
?>
<div>Hello</div>
